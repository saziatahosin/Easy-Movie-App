package com.example.easymovie;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;


public class HomeFragment extends Fragment implements View.OnClickListener{
    Button bookmyshow, Searchshow, Feedback;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        bookmyshow = view.findViewById(R.id.bookmyshowid);
        Searchshow = view.findViewById(R.id.searchshowid);
        Feedback = view.findViewById(R.id.feedbackid);

        Searchshow.setOnClickListener(this);

        bookmyshow.setOnClickListener(this);

        Feedback.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.bookmyshowid){
            Intent myIntent = new Intent(getContext(), bookshow.class);
            startActivity(myIntent);
        }
        if (v.getId() == R.id.searchshowid){
            Intent myIntent = new Intent(getContext(), Search.class);
            startActivity(myIntent);
        }
        if (v.getId() == R.id.feedbackid){
            Intent myIntent = new Intent(getContext(), feedback.class);
            startActivity(myIntent);
        }
    }
}
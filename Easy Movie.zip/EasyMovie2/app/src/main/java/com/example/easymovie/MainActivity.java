package com.example.easymovie;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void userReg(View view) {
        Intent regIntent = new Intent(this, registration.class);
        startActivity(regIntent);
    }

    public void userLogin(View view) {
        Intent loginIntent = new Intent(this, login.class);
        startActivity(loginIntent);
    }

    public void AdminLogin(View view) {
        //Intent adminsigninIntent = new Intent(this, adminsignin.class);
        //startActivity(adminsigninIntent);
    }


}
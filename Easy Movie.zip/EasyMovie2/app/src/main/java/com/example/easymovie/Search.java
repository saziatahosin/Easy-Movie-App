package com.example.easymovie;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;

public class Search extends AppCompatActivity {
SearchView mySearchView;
ListView myList;
ArrayList<String> list;
ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        mySearchView = (SearchView)findViewById(R.id.searchviewid);
        myList = (ListView)findViewById(R.id.listviewid);
        list=new ArrayList<String>();
        list.add("Movie Name:Frozen" + "Available Seat:45" + "Cost:500 TK");
        list.add("Movie Name:Encanto" + "Available Seat:40" + "Cost:500 TK");
        list.add("Movie Name:Stranger World" + "Available Seat:50" + "Cost:500 TK");
        list.add("Movie Name:Coraline" + "Available Seat:60" + "Cost:500 TK");
        list.add("Movie Name:Zootapia" + "Available Seat:44" + "Cost:500 TK");
        list.add("Movie Name:Frozen 2" + "Available Seat:67" + "Cost:500 TK");
        list.add("Movie Name:Tangled" + "Available Seat:37" + "Cost:500 TK");
        list.add("Movie Name:Moana" + "Available Seat:69" + "Cost:500 TK");
        list.add("Movie Name:Raya" + "Available Seat:48" + "Cost:500 TK");
        list.add("Movie Name:Big Hero 6" + "Available Seat:63" + "Cost:500 TK");
        list.add("Movie Name:Kung Fu Panda" + "Available Seat:90" + "Cost:500 TK");
        list.add("Movie Name:Coco" + "Available Seat:56" + "Cost:500 TK");
        list.add("Movie Name:Onward" + "Available Seat:38" + "Cost:500 TK");

        adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1);
        myList.setAdapter(adapter);
        mySearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                adapter.getFilter().filter(s);
                return false;
            }
        });




    }
}
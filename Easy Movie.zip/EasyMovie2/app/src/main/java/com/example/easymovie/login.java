package com.example.easymovie;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login extends AppCompatActivity implements  View.OnClickListener {
    FirebaseAuth firebaseAuth;
    EditText emailEditText, passEditText;
    Button loginButton;
    //ProgressDialog loadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        firebaseAuth = FirebaseAuth.getInstance();
        emailEditText = findViewById(R.id.EmailEditTextid);
        passEditText = findViewById(R.id.passEditTextid);
        loginButton = findViewById(R.id.loginButtonid);
        loginButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String username = emailEditText.getText().toString().trim();
        String pass = passEditText.getText().toString().trim();


        if (view.getId() == R.id.loginButtonid) {

            if (!username.isEmpty() && !pass.isEmpty()) {

                firebaseAuth.signInWithEmailAndPassword(username, pass).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Toast.makeText(login.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(login.this, nav_bar.class));
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText(login.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });

            } else {
                Toast.makeText(this, "Enter email & password", Toast.LENGTH_SHORT).show();
            }
        }
    }
}



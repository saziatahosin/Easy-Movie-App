package com.example.easymovie;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class registration extends AppCompatActivity {

    private FirebaseAuth mAuth;
    EditText nameEditText, emailEditText, phoneEditText, passEditText;
    Button btnSignUp;

    ProgressDialog loadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        mAuth = FirebaseAuth.getInstance();

        loadingBar = new ProgressDialog(this);

        nameEditText = findViewById(R.id.nameEditTextid);
        emailEditText = findViewById(R.id.emailEditTextid);
        phoneEditText = findViewById(R.id.phoneEditTextid);
        passEditText = findViewById(R.id.passowordEditTextid);
        btnSignUp = findViewById(R.id.registrationid);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = emailEditText.getText().toString();
                String pass = passEditText.getText().toString();

                SignUpUser(email, pass);
            }
        });
    }

    private void SignUpUser(String email, String pass) {
        if (TextUtils.isEmpty(email)){
            Toast.makeText(this, "Please Enter Your Email", Toast.LENGTH_SHORT).show();
        }
        if (TextUtils.isEmpty(pass)){
            Toast.makeText(this, "Please Enter Your Password", Toast.LENGTH_SHORT).show();
        }
        else{
            loadingBar.setTitle("Registration");
            loadingBar.setMessage("Please wait, it will take some time");
            loadingBar.show();

            mAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        Toast.makeText(registration.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(registration.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                    }
                    loadingBar.dismiss();
                }
            });
        }
    }
}